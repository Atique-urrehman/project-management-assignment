// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows: expect(element).toHaveTextContent(...)
import '@testing-library/jest-dom';
