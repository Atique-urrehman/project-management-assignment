import React from 'react';
import insightsData from '../data/standards.json'; 

// Utility function to convert **markdown** to <b>HTML</b>
// This is essential because React does not automatically convert **text** to bold.
const markdownToHtml = (markdown) => {
    // Replace **text** with <b>text</b>
    if (!markdown) return '';
    return markdown.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
};

function InsightsDashboard() {
    // Access the insights object directly
    const insights = insightsData.insights || {};
    
    // Safety check to ensure the arrays exist, even if empty
    const similarities = insights.similarities || [];
    const differences = insights.differences || []; // <-- Ensure this array is correctly populated in your JSON
    const uniquePoints = insights.uniquePoints || [];

    return (
        <div className="insights-dashboard">
            <h2>Key Insights and Comparative Summary</h2>
            
            {/* 1. SIMILARITIES SECTION */}
            <section className="insight-section">
                <h3>✅ Similarities (Common Practices)</h3>
                <ul>
                    {similarities.map((item, index) => (
                        <li 
                            key={index}
                            // Apply converter and render as HTML
                            dangerouslySetInnerHTML={{ __html: markdownToHtml(item) }}
                        />
                    ))}
                </ul>
            </section>

            <hr />

            {/* 2. DIFFERENCES SECTION */}
            <section className="insight-section">
                <h3>↔️ Differences (Unique Terminologies/Methodologies)</h3>
                <ul>
                    {/* This loop is targeting the insights.differences array */}
                    {differences.map((item, index) => (
                        <li 
                            key={index}
                            // Apply converter and render as HTML
                            dangerouslySetInnerHTML={{ __html: markdownToHtml(item) }}
                        />
                    ))}
                    {differences.length === 0 && (
                        <li>No detailed difference points found in the data file.</li>
                    )}
                </ul>
            </section>

            <hr />

            {/* 3. UNIQUE POINTS SECTION */}
            <section className="insight-section">
                <h3>✨ Unique Points (What only one standard covers)</h3>
                <div className="unique-points-grid">
                    {uniquePoints.map((item, index) => (
                        <div key={index} className="unique-point-card">
                            <strong>{item.standard}:</strong> 
                            <span dangerouslySetInnerHTML={{ __html: markdownToHtml(item.point) }} />
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}

export default InsightsDashboard;